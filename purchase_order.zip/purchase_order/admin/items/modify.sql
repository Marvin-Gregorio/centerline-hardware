USE purchase_order_db;

SELECT item_list;

ALTER TABLE item_list
ADD DateOfBirth date;
s